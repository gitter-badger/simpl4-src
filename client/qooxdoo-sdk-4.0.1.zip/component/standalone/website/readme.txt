Here, the deliverables for the qooxdoo component 'qx.Website' are being built.
