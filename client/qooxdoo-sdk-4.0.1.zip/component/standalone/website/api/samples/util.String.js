addSample("q.string.camelCase ", {
  javascript: function() {
    console.log(q.string.camelCase("I-like-cookies"));
  },
  executable: true
});