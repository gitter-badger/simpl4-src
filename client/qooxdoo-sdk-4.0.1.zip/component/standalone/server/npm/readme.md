qx.Server
-----------

A small library that provides a classical OO system with classes, mixins,
interfaces, dynamic getters/setters, custom events and data binding.

qx.Server, a component of the qooxdoo JavaScript framework, provides a
foundation for scalable DOM-less browser and server development. For docs,
license and further downloads, see: http://qooxdoo.org/

