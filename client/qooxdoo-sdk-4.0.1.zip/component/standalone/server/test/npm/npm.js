var qx = require('qooxdoo');
require('./test.js');