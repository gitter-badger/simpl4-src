/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.modern.Theme",
{
  meta :
  {
    color : ${Namespace}.theme.modern.Color,
    decoration : ${Namespace}.theme.modern.Decoration,
    font : ${Namespace}.theme.modern.Font,
    appearance : ${Namespace}.theme.modern.Appearance,
    icon : qx.theme.icon.Tango
  }
});