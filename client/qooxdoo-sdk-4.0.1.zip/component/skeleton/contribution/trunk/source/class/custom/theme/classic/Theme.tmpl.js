/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.classic.Theme",
{
  meta :
  {
    color : ${Namespace}.theme.classic.Color,
    decoration : ${Namespace}.theme.classic.Decoration,
    font : ${Namespace}.theme.classic.Font,
    appearance : ${Namespace}.theme.classic.Appearance,
    icon : qx.theme.icon.Oxygen
  }
});