/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.classic.Font",
{
  extend : qx.theme.classic.Font,

  fonts :
  {
  }
});