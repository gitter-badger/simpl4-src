/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.modern.Color",
{
  extend : qx.theme.modern.Color,

  colors :
  {
  }
});