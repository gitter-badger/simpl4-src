/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.classic.Appearance",
{
  extend : qx.theme.classic.Appearance,

  appearances :
  {
  }
});