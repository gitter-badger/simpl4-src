/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.modern.Decoration",
{
  extend : qx.theme.modern.Decoration,

  decorations :
  {
  }
});