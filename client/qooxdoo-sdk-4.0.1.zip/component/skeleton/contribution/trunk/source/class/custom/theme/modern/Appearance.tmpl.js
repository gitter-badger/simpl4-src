/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.modern.Appearance",
{
  extend : qx.theme.modern.Appearance,
  
  appearances :
  {
  }
});