/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.classic.Color",
{
  extend : qx.theme.classic.Color,

  colors :
  {
  }
});