/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.classic.Decoration",
{
  extend : qx.theme.classic.Decoration,

  decorations :
  {
  }
});