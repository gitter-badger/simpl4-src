/** <h3> ${Namespace} API Documentation </h3>
 *
 * This text will be used in the API documentation of your contribution
 * generated with __generate.py api__. You should replace this text with an
 * overview of your contribution and an introduction on how to use it.
 *
 */
