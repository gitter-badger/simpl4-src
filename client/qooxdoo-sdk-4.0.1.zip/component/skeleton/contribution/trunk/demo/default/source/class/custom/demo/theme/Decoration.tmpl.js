/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.demo.theme.Decoration",
{
  extend : qx.theme.modern.Decoration,

  decorations :
  {
  }
});