/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.demo.theme.Theme",
{
  meta :
  {
    color : ${Namespace}.demo.theme.Color,
    decoration : ${Namespace}.demo.theme.Decoration,
    font : ${Namespace}.demo.theme.Font,
    icon : qx.theme.icon.Tango,
    appearance : ${Namespace}.demo.theme.Appearance
  }
});