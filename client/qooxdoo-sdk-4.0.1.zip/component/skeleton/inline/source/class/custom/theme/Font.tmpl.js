/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.Font",
{
  extend : qx.theme.modern.Font,

  fonts :
  {
  }
});