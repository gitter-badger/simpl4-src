/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.Decoration",
{
  extend : qx.theme.modern.Decoration,

  decorations :
  {
  }
});