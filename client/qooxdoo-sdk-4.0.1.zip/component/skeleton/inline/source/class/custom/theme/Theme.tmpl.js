/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("${Namespace}.theme.Theme",
{
  meta :
  {
    color : ${Namespace}.theme.Color,
    decoration : ${Namespace}.theme.Decoration,
    font : ${Namespace}.theme.Font,
    icon : qx.theme.icon.Tango,
    appearance : ${Namespace}.theme.Appearance
  }
});