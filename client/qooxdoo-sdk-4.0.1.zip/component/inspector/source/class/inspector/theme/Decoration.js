/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("inspector.theme.Decoration",
{
  extend : qx.theme.indigo.Decoration,

  decorations :
  {
  }
});