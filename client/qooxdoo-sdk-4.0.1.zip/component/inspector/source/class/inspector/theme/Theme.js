/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("inspector.theme.Theme",
{
  meta :
  {
    color : inspector.theme.Color,
    decoration : inspector.theme.Decoration,
    font : inspector.theme.Font,
    icon : qx.theme.icon.Tango,
    appearance : inspector.theme.Appearance
  }
});