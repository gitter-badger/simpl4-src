/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("inspector.theme.Color",
{
  extend : qx.theme.indigo.Color,

  colors :
  {
  }
});