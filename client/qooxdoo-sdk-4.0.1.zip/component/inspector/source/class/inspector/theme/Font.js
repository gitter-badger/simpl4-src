/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("inspector.theme.Font",
{
  extend : qx.theme.indigo.Font,

  fonts :
  {
  }
});