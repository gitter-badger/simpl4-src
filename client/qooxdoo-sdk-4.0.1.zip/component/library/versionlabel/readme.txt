VersionLabel - A basic label containing the qooxdoo version
===========================================================

Used in place of a plain qx.ui.basic.Label where a version string is desired.
This keeps calculation of that version string in one place.

short:: creates a label with a version string in it
