/**
 * qxc.ui.versionlabel package
 *
 */
