Indigo Style Resources
======================

This library contains resources such as CSS files and images which can be 
used to style web apps similar to the design of qooxdoo.org.

These resources are *not* required by the Indigo theme for RIA applications that
is distributed with the SDK.