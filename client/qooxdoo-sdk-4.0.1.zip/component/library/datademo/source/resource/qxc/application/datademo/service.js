callback([
  {
    text: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore", 
    user: {
      profile_image_url : "http://www.gravatar.com/avatar/7c366401a0b7a57c50e5c38913ddc135.png",
      name : "qooxdoo",
      location: "Karlsruhe"
    },
    created_at: 1373541470150
  },
  {
    text: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam", 
    user: {
      profile_image_url : "http://www.gravatar.com/avatar/00000000000000000000000000000000.png",
      name: "none",
      location : "Away"
    },
    created_at: 1373541361356
  },
  {
    text: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor", 
    user: {
      profile_image_url : "http://www.gravatar.com/avatar/74e78850f9d01ddce817dd5f83f3ac0d.png",
      name: "Martin",
      location : "Home"
    },
    created_at: 1373541270150
  }
]);