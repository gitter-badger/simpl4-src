qx.Class.define("apiviewer.test.StringExtend", {
  extend : String,

  members : {}
});