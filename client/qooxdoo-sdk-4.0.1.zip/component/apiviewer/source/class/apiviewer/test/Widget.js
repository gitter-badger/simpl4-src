qx.Class.define("apiviewer.test.Widget",
{
  extend : apiviewer.test.LayoutItem,

  members :
  {
    // overridden
    renderSeparator : function(separator, bounds) {
      // empty template
    }
  }
});